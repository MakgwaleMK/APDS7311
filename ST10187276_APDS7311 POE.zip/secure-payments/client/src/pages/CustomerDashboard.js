import React, { useState } from 'react';
import axios from 'axios';
import './FormStyles.css';

const CustomerDashboard = () => {
  const [formData, setFormData] = useState({
    amount: '',
    currency: 'USD',
    provider: 'SWIFT',
    recipientAccount: '',
    swiftCode: ''
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');

    try {
      const res = await axios.post('http://localhost:5000/api/payments', formData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      setMessage('Payment submitted successfully!');
      setFormData({ amount: '', currency: 'USD', provider: 'SWIFT', recipientAccount: '', swiftCode: '' });
    } catch (err) {
      console.error(err);
      setMessage('Failed to submit payment.');
    }
  };

  return (
    <div className="form-container">
      <h2>Customer Dashboard</h2>
      <form onSubmit={handleSubmit} className="form">
        <input
          type="number"
          name="amount"
          placeholder="Enter Amount"
          value={formData.amount}
          onChange={handleChange}
          required
        />

        <select name="currency" value={formData.currency} onChange={handleChange} required>
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
        </select>

        <select name="provider" value={formData.provider} onChange={handleChange} required>
          <option value="SWIFT">SWIFT</option>
        </select>

        <input
          type="text"
          name="recipientAccount"
          placeholder="Recipient Account Number"
          value={formData.recipientAccount}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="swiftCode"
          placeholder="SWIFT Code"
          value={formData.swiftCode}
          onChange={handleChange}
          required
        />

        <button type="submit">Pay Now</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default CustomerDashboard;
