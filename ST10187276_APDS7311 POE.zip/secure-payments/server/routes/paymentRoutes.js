// routes/paymentRoutes.js
const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middleware/auth');

// @route POST /api/payments
// @desc Create a new international payment
router.post('/', authMiddleware, [
  body('amount').isFloat({ gt: 0 }),
  body('currency').isString().isLength({ min: 3, max: 3 }),
  body('payeeAccount').matches(/^[0-9]{10,}$/),
  body('swiftCode').matches(/^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/)
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const payment = new Payment({
      customerId: req.user.id,
      amount: req.body.amount,
      currency: req.body.currency,
      provider: req.body.provider || 'SWIFT',
      payeeAccount: req.body.payeeAccount,
      swiftCode: req.body.swiftCode
    });

    await payment.save();
    res.status(201).json({ message: 'Payment submitted', payment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// @route GET /api/payments
// @desc Get all payments (employees only)
router.get('/', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'employee') return res.status(403).json({ error: 'Access denied' });
    const payments = await Payment.find().populate('customerId', 'fullName accountNumber');
    res.json(payments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// @route PUT /api/payments/:id/verify
// @desc Verify a payment (employees only)
router.put('/:id/verify', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'employee') return res.status(403).json({ error: 'Access denied' });
    const payment = await Payment.findById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found' });

    payment.status = 'verified';
    await payment.save();
    res.json({ message: 'Payment verified', payment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
